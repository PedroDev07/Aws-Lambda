# Aws-Lambda
Scripts para aws lambda em python
